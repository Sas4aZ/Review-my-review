<?php

require_once "config.php";
//getting id from url
$id = $_GET ['id'];
//selecting data associated into this particular id
$sql = "SELECT * FROM complaint WHERE id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

if ($_SERVER['REQUEST_METHOD']== "POST") {
    $sql= "UPDATE complaint name=?, complaint=?, complaint_type=? WHERE id=?";
    if($stmt=mysqli_prepare($conn, $sql)) {
        // $id_param =$id;
        mysqli_stmt_bind_param($stmt, "sssi", $name,$complaint, $complaint_type);
        $id_param= $id;
        $First_name=$POST["name"];
        $Last_name=$POST["complaint"];
        $Email=$POST["complaint_type"];
    }
}
?>

<html>
<head>
    <title>Edit data</title>
</head>
<body>
<a href ="retrieve_to.php"> Home</a>
<br><br>
<form method ="post" action="">
    <input type= "text" name="name" value="<?php echo $row['name']; ?>"<br>
    <input type= "text" name="complaint" value="<?php echo $row['complaint'];?>"<br>
    <input type= "email" name="complaint_type"  value="<?php echo $row['complaint_type'];?> "<br>
    <input type= "submit" value="update">
</form>
</body>
</html>
